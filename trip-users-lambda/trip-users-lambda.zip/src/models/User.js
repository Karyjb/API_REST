"use strict";
// src/MyClass.ts
//Object.defineProperty(exports, "__esModule", { value: true });
export class User {
    constructor(name, id, identification_number, mail, phone, rh, pwd) {
        this.name = name;
        this.id = id;
        this.identification_number = identification_number;
        this.mail = mail;
        this.phone = phone;
        this.rh = rh;
        this.pwd = pwd;
    }
}

