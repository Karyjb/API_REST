import { createRequire } from "module";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  UpdateCommand,
  ScanCommand,
  PutCommand,
  GetCommand,
  DeleteCommand,
} from "@aws-sdk/lib-dynamodb";

import { User } from "./models/User.js";

console.log("Hello people");

const require = createRequire(import.meta.url);

//const User = require("./models/User").default;

const { v4: uuidv4 } = require("uuid");

const client = new DynamoDBClient({});

const dynamo = DynamoDBDocumentClient.from(client);

const tableName = "trip-users";

export const handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json",
  };

  try {
    console.log("event: ", event);
    event = JSON.parse(event.body);
    console.log("event: ", event);
    console.log(event.routeKey);
    const requestJSON = JSON.parse(event.body);
    console.log("requestJSON: ", requestJSON);
    switch (event.routeKey) {
      case "DELETE /items/{id}":
        console.log("DELETE /items/{id}");
        let keyDelete = {
          TableName: tableName,
          Key: {
            id: event.pathParameters.id,
          },
        };

        await dynamo.send(new DeleteCommand(keyDelete));
        console.log("keyDelete", keyDelete);
        body = `Deleted item ${keyDelete.Key.id}`;
        break;
      case "GET /items/{id}":
        let keyDynamo = {
          TableName: tableName,
          Key: {
            id: event.pathParameters.id,
          },
        };
        console.log("keyDynamo", keyDynamo);

        body = await dynamo.send(new GetCommand(keyDynamo));
        body = body.Item;
        break;
      case "GET /items":
        body = await dynamo.send(new ScanCommand({ TableName: tableName }));
        body = body.Items;
        break;
      case "UPDATE /items/{id}":
        //let name = requestJSON.name;
        console.log("UPDATE1 ");
        let params = {
          TableName: tableName,
          Key: {
            id: event.pathParameters.id,
          },
          Projectionexpression: "#n",
          ExpressionAttributeNames: {
            "#n": "name",
            
          },
          UpdateExpression: "set #n = :n , rh = :rh, mail = :mail, identification_number = :identification_number, phone = :phone, pwd = :pwd",
          ExpressionAttributeValues: {
            ":n": requestJSON.name,
            ":rh": requestJSON.rh,
            ":mail": requestJSON.mail,
            ":identification_number": requestJSON.identification_number,
            ":phone": requestJSON.phone,
            ":pwd": requestJSON.pwd,
            ":rh": requestJSON.rh,
          },
        };
      
        console.log("params", params);
        console.log("update 2");
        await dynamo.send(new UpdateCommand(params));
        body = `UPDATE /items ${params.Key.id}`;
        break;

      case "PUT /items":
        console.log("PUT /items");
        //let requestJSON = JSON.parse(event.body);
        console.log("requestJSON: ", requestJSON);
        let itemDynamo = {
          TableName: tableName,
          Item: {
            id: uuidv4(),
            identification_number: requestJSON.identification_number,
            name: requestJSON.name,
            mail: requestJSON.mail,
            phone: requestJSON.phone,
            pwd: requestJSON.pwd,
            rh: requestJSON.rh,
            //idViaje: requestJSON.idViaje,
          },
        };
        console.log("itemDynamo", itemDynamo);
        await dynamo.send(new PutCommand(itemDynamo));
        body = `Put item ${itemDynamo.Item.id}`;
        break;
      case "POST /login":
        login(requestJSON.mail, requestJSON.pwd);

        break;
      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }

    async function login(mail, pwd) {
      let user = new User();
      user = await getUser(mail);
      if (pwd == user.pwd) {
        return console.log("login ok");
      } else {
        return "bad login";
      }
    }

    async function getUser(mail) {
      let keyDynamo = {
        TableName: tableName,
        Key: {
          mail: mail,
        },
      };
      console.log("keyDynamo", keyDynamo);

      return await dynamo.send(new GetCommand(keyDynamo));
    }
  } catch (err) {
    statusCode = 400;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
    console.log(body);
  }

  return {
    statusCode,
    body,
    headers,
  };
};


const EventEmitter = require('events')
const myEmitter = new EventEmitter()

var request = {
  body : '{"routeKey":"UPDATE /items/{id}", "body":"{\"identification_number\"1078370957,\"name\":\"Luz Jimenez\",\"mail\":\"kary,jimenez1127@gmail.com\",\"phone\":88889877,\"pwd\":\"Esmeralda@\",\"rh\":\"A-\"}","pathParameters":{"id": "a0b5a7ee-0dc5-4236-a6fc-d26a1fb593e9"}}',
 
  /* Request GET /users/{id}
body : '{"routeKey":"GET /items/{id}", "body":"{}","pathParameters":{"id": "a0b5a7ee-0dc5-4236-a6fc-d26a1fb593e9"}}',
pathParameters: '{"id": "a0b5a7ee-0dc5-4236-a6fc-d26a1fb593e9"}',
routeKey: 'GET /items/{id}'*/ 
}
myEmitter.on('event', async () => {
  const dogs = await handler(request)
  console.log(handler)
})
myEmitter.emit('event')
